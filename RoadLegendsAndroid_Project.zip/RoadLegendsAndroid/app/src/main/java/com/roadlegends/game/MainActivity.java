package com.roadlegends.game;

import android.app.Activity;
import android.os.Bundle;
import android.view.*;
import android.graphics.*;
import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import java.util.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) { super.onCreate(b); getWindow().getDecorView().setSystemUiVisibility(5894|1024|512); setContentView(new GameView(this)); }

    static class GameView extends View {
        Paint p = new Paint(3);
        Random rnd = new Random();
        String[] names={"Fiat 500","Mercedes C-Class","BMW M4","Porsche 911","McLaren 720S","Audi R8","Lamborghini Huracán","Nissan GT-R","Toyota Supra","Ford Mustang"};
        int[] colors={Color.rgb(232,194,65),0xffd9e1eb,0xff388de0,0xffdf4439,0xffff852c,0xff888e9a,0xffa9d343,0xffa83e45,0xffe8e8e8,0xff3b78ba};
        int[] prices={0,350,800,1500,2600,3900,5500,7200,9000,12000};
        boolean[] owned=new boolean[10];
        int selected=0, money=0, level=1, best=0, runCoins=0;
        float playerX=0, targetX=0, speed=0, roadMove=0, distance=0;
        boolean running=false, nitro=false, brake=false;
        long last=0;
        ArrayList<Traffic> traffic=new ArrayList<>();
        String message="اضغط ابدأ السباق";
        RectF leftBtn=new RectF(),rightBtn=new RectF(),nitroBtn=new RectF(),brakeBtn=new RectF(),startBtn=new RectF(),garageBtn=new RectF();
        int mode=0; // 0 menu, 1 race, 2 garage, 3 result
        float scaleX,scaleY;
        GameView(Context c){super(c); owned[0]=true; setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        void fill(Canvas c,int color,float l,float t,float r,float b){p.setColor(color);p.setStyle(Paint.Style.FILL);c.drawRect(l,t,r,b,p);}
        void round(Canvas c,int color,float l,float t,float r,float b,float rad){p.setColor(color);p.setStyle(Paint.Style.FILL);c.drawRoundRect(l,t,r,b,rad,rad,p);}
        void text(Canvas c,String s,float x,float y,int size,int color,boolean bold){p.setColor(color);p.setTextSize(size);p.setTypeface(bold?Typeface.create("sans-serif",Typeface.BOLD):Typeface.create("sans-serif",Typeface.NORMAL));p.setTextAlign(Paint.Align.CENTER);c.drawText(s,x,y,p);}
        void poly(Canvas c,int color,float... a){Path path=new Path();path.moveTo(a[0],a[1]);for(int i=2;i<a.length;i+=2)path.lineTo(a[i],a[i+1]);path.close();p.setColor(color);c.drawPath(path,p);}
        @Override protected void onDraw(Canvas raw){
            super.onDraw(raw); Canvas c=raw; float sx=getWidth()/900f, sy=getHeight()/520f; c.save();c.scale(sx,sy);
            drawWorld(c);
            if(mode==0)drawMenu(c); else if(mode==1)drawHud(c); else if(mode==2)drawGarage(c); else drawResult(c);
            c.restore();
            if(mode==1){ long now=System.currentTimeMillis(); if(last==0)last=now; float dt=Math.min((now-last)/16f,2.5f);last=now; update(dt); postInvalidateDelayed(16);}
        }
        void drawWorld(Canvas c){
            p.setShader(new LinearGradient(0,0,0,230,0xff102b4a,0xff8bb1bd,Shader.TileMode.CLAMP));c.drawRect(0,0,900,230,p);p.setShader(null);
            p.setColor(0xffffd68a);c.drawCircle(730,75,31,p);
            poly(c,0xff344e48,0,220,120,115,240,220,380,125,510,220,670,120,900,220,900,520,0,520);
            fill(c,0xff24402f,0,220,900,520);
            poly(c,0xff343a43,365,185,535,185,890,520,10,520);
            poly(c,0xffe5d7ac,354,185,365,185,10,520,0,520);poly(c,0xffe5d7ac,535,185,546,185,900,520,890,520);
            for(int i=0;i<10;i++){float t=((i*65+roadMove)%650)/650f;float y=190+t*330;float half=85+t*355;float cx=450;float dash=8+t*14;fill(c,0xffe7e9ed,cx-half/3-dash/2,y,cx-half/3+dash/2,y+5+t*14);fill(c,0xffe7e9ed,cx+half/3-dash/2,y,cx+half/3+dash/2,y+5+t*14);}
            for(int i=0;i<9;i++){float y=190+((i*93+roadMove*1.3f)%340);float t=(y-190)/330f;float x=450+(i%2==0?-1:1)*(120+250*t);p.setColor(0xff183526);c.drawCircle(x,y,12+20*t,p);p.setColor(0xff47734a);c.drawCircle(x-5*t,y-8*t,10+18*t,p);}
            for(Traffic t:traffic) drawCar(c,450+t.x, t.y, t.color, .43f+t.y/1000f,false);
            // third-person player car, rear view with visible roof, bumper and wheels
            drawCar(c,450+playerX,410,colors[selected],1.45f,true);
        }
        void drawCar(Canvas c,float x,float y,int color,float s,boolean hero){
            c.save();c.translate(x,y);c.scale(s,s);
            p.setColor(0xff080c13);c.drawRoundRect(-43,-56,43,65,16,16,p);
            p.setColor(color);c.drawRoundRect(-37,-63,37,59,17,17,p);
            p.setColor(0xff172b3e);Path w=new Path();w.moveTo(-27,-37);w.lineTo(-18,-53);w.lineTo(18,-53);w.lineTo(27,-37);w.lineTo(24,-12);w.lineTo(-24,-12);w.close();c.drawPath(w,p);
            p.setColor(0xff86b5ce);c.drawRoundRect(-19,-47,19,-18,7,7,p);
            p.setColor(0xff202a35);c.drawRoundRect(-25,2,25,34,7,7,p);
            p.setColor(0xfff6e6bb);c.drawRoundRect(-32,-58,-17,-51,3,3,p);c.drawRoundRect(17,-58,32,-51,3,3,p);
            p.setColor(0xfff04444);c.drawRoundRect(-32,42,-18,52,3,3,p);c.drawRoundRect(18,42,32,52,3,3,p);
            p.setColor(0xff090b10);c.drawRoundRect(-45,-34,-34,-4,4,4,p);c.drawRoundRect(34,-34,45,-4,4,4,p);c.drawRoundRect(-45,26,-34,53,4,4,p);c.drawRoundRect(34,26,45,53,4,4,p);
            if(hero){p.setColor(0x66ffffff);c.drawRoundRect(-12,37,12,40,2,2,p);}
            c.restore();
        }
        void update(float dt){
            if(mode!=1)return;
            float max=nitro?255:brake?90:175+level*7;speed+=(max-speed)*.045f*dt;
            roadMove+=speed*.09f*dt;distance+=speed*.035f*dt;
            if(rnd.nextFloat()<.018f*dt+level*.001f){traffic.add(new Traffic((rnd.nextInt(3)-1)*105,-70,rnd.nextInt(3)==0?0xffd94b43:rnd.nextInt(3)==1?0xffd3dce5:0xff4d9ab8));}
            Iterator<Traffic> it=traffic.iterator();while(it.hasNext()){Traffic t=it.next();t.y+=(speed*.055f+2+level*.2f)*dt;
                if(!t.passed&&t.y>330){t.passed=true;if(Math.abs(t.x-playerX)>48&&Math.abs(t.x-playerX)<112){runCoins+=25;message="تجاوز قريب +25";}}
                if(Math.abs(t.x-playerX)<48&&t.y>335&&t.y<480){finish();return;}if(t.y>600)it.remove();
            }
            playerX+=(targetX-playerX)*.16f*dt;playerX=Math.max(-135,Math.min(135,playerX));
            if(distance>level*1800){level++;message="مستوى جديد!";}
        }
        void drawHud(Canvas c){
            round(c,0xdd101c2c,16,14,240,82,15);text(c,"ROAD LEGENDS",128,39,19,0xffffbd48,true);text(c,""+money+"  $",128,65,19,Color.WHITE,true);
            round(c,0xdd101c2c,690,14,884,82,15);text(c,"LEVEL "+level,787,43,20,Color.WHITE,true);text(c,Math.round(speed)+" KM/H",787,67,15,0xffffcf71,true);
            text(c,message,450,120,22,0xffffdc83,true);
            round(c,0xcc101c2c,16,445,884,508,14);text(c,"المسافة "+(int)distance+" m",150,484,18,Color.WHITE,true);text(c,"مكافآت السباق "+runCoins+" $",450,484,18,0xffffcf71,true);
            leftBtn.set(22,320,145,440);rightBtn.set(755,320,878,440);nitroBtn.set(710,445,880,510);brakeBtn.set(20,445,190,510);
            round(c,0xaae6edf7,22,320,145,440,22);round(c,0xaae6edf7,755,320,878,440,22);text(c,"◀",83,390,46,0xff111b2a,true);text(c,"▶",817,390,46,0xff111b2a,true);
            round(c,0xffe9a52e,710,445,880,510,14);text(c,"NITRO ⚡",795,485,21,0xff17120a,true);round(c,0xff9b3434,20,445,190,510,14);text(c,"فرامل",105,485,20,Color.WHITE,true);
            round(c,0xff263a53,345,14,555,82,15);text(c,"قريب من السيارات = فلوس",450,53,16,Color.WHITE,true);
        }
        void drawMenu(Canvas c){
            shade(c);text(c,"ROAD LEGENDS",450,115,49,0xffffb938,true);text(c,"ULTIMATE STREET RACING",450,151,17,Color.WHITE,true);
            drawCar(c,450,280,colors[selected],1.7f,true);
            round(c,0xffe9a52e,280,370,620,435,18);text(c,"ابدأ السباق",450,411,27,0xff16120b,true);
            round(c,0xff263b55,280,450,620,505,15);text(c,"الجراج واختيار السيارات",450,485,20,Color.WHITE,true);
            text(c,"فلوس السباق: "+money+" $     أفضل مسافة: "+best,450,340,18,Color.WHITE,true);
            startBtn.set(280,370,620,435);garageBtn.set(280,450,620,505);
        }
        void shade(Canvas c){fill(c,0xaa08111f,0,0,900,520);}
        void drawGarage(Canvas c){
            shade(c);text(c,"جراج السيارات",450,52,32,0xffffbd48,true);text(c,"رصيدك: "+money+" $",450,84,19,Color.WHITE,true);
            for(int i=0;i<names.length;i++){int col=i%5,row=i/5;float x=18+col*178,y=112+row*155;
                round(c,selected==i?0xff42516a:0xff1b2a40,x,y,x+165,y+137,13);drawCar(c,x+82,y+57,colors[i],.65f,false);
                text(c,names[i],x+82,y+105,14,Color.WHITE,true);text(c,owned[i]?"مملوكة":prices[i]+" $",x+82,y+126,13,0xffffcb72,true);
            }
            round(c,0xffe9a52e,330,435,570,490,14);text(c,"رجوع",450,471,21,0xff17120a,true);text(c,"اضغط على سيارة لاختيارها أو شرائها",450,420,15,Color.WHITE,false);garageBtn.set(330,435,570,490);
        }
        void drawResult(Canvas c){shade(c);text(c,"انتهى السباق!",450,135,42,0xffffbd48,true);text(c,"المسافة: "+(int)distance+" متر",450,205,25,Color.WHITE,true);text(c,"كسبت: "+runCoins+" $",450,250,25,0xffffd27c,true);round(c,0xffe9a52e,300,330,600,395,16);text(c,"سباق جديد",450,372,24,0xff17120a,true);round(c,0xff263b55,300,415,600,480,16);text(c,"الجراج",450,455,22,Color.WHITE,true);startBtn.set(300,330,600,395);garageBtn.set(300,415,600,480);}
        @Override public boolean onTouchEvent(android.view.MotionEvent e){
            float x=e.getX()*900/getWidth(),y=e.getY()*520/getHeight();
            if(mode==1){
                if(e.getAction()==MotionEvent.ACTION_DOWN||e.getAction()==MotionEvent.ACTION_MOVE){
                    if(x<180&&y>300&&y<445)targetX=-125;else if(x>720&&y>300&&y<445)targetX=125;
                    nitro=x>690&&y>440; brake=x<200&&y>440;
                }
                if(e.getAction()==MotionEvent.ACTION_UP){nitro=false;brake=false;targetX=0;}
                return true;
            }
            if(e.getAction()!=MotionEvent.ACTION_UP)return true;
            if(mode==0){if(startBtn.contains(x,y)){startRace();}else if(garageBtn.contains(x,y)){mode=2;}}
            else if(mode==2){
                if(garageBtn.contains(x,y)){mode=0;}
                else if(y>=100&&y<420){int col=(int)((x-18)/178),row=(int)((y-112)/155);int i=row*5+col;if(i>=0&&i<10&&col>=0&&col<5){if(owned[i])selected=i;else if(money>=prices[i]){money-=prices[i];owned[i]=true;selected=i;message="تم شراء "+names[i];}else message="فلوسك مش كفاية";}}
            } else if(mode==3){if(startBtn.contains(x,y))startRace();else if(garageBtn.contains(x,y))mode=2;}
            invalidate();return true;
        }
        void startRace(){traffic.clear();distance=0;runCoins=0;speed=100;playerX=0;targetX=0;mode=1;last=System.currentTimeMillis();message="انطلق!";invalidate();}
        void finish(){mode=3;money+=runCoins;best=Math.max(best,(int)distance);level=Math.max(level,1+best/1800);running=false;invalidate();}
    }
    static class Traffic {float x,y;int color;boolean passed=false;Traffic(float a,float b,int c){x=a;y=b;color=c;}}
}
